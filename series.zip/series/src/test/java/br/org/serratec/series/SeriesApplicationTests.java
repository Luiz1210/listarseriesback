package br.org.serratec.series;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
